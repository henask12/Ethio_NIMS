﻿using EProcurement.DataObjects.Models.MasterData;
using EProcurement.Core;
using EProcurement.DataObjects;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using EProcurement.DataObjects.Models.MasterData;
using EProcurement.DataObjects.Models.Operational;
using CargoProrationAPI.DataObjects.Models.Operational;
using CargoProrationAPI.DataObjects.Models.Report;
using CargoProrationAPI.DataObjects.Models.Operational.Negotiation;
using CargoProrationAPI.DataObjects.Models.Operational.NegotiationEvaluation;
using CargoProrationAPI.DataObjects.Models.MasterData;
using CargoProrationAPI.DataObjects.Models.Operational.Financial;

namespace EProcurement.Api
{
    public class RepositoryInstaller : IInstaller
    {
        public void InstallServices(IServiceCollection services, IConfiguration configuration)
        {
            #region master data
            services.AddScoped(typeof(IRepositoryBase<Supplier>), typeof(RepositoryBase<Supplier>));            
            services.AddScoped(typeof(IRepositoryBase<CostCenter>), typeof(RepositoryBase<CostCenter>));            
            services.AddScoped(typeof(IRepositoryBase<Person>), typeof(RepositoryBase<Person>));            
            services.AddScoped(typeof(IRepositoryBase<Office>), typeof(RepositoryBase<Office>));            
            services.AddScoped(typeof(IRepositoryBase<Country>), typeof(RepositoryBase<Country>));            
            services.AddScoped(typeof(IRepositoryBase<Station>), typeof(RepositoryBase<Station>));            
            services.AddScoped(typeof(IRepositoryBase<BusinessCategoryType>), typeof(RepositoryBase<BusinessCategoryType>));            
            services.AddScoped(typeof(IRepositoryBase<BusinessCategory>), typeof(RepositoryBase<BusinessCategory>));            
            services.AddScoped(typeof(IRepositoryBase<SupplierBusinessCategory>), typeof(RepositoryBase<SupplierBusinessCategory>));            
            services.AddScoped(typeof(IRepositoryBase<VendorType>), typeof(RepositoryBase<VendorType>));            
            services.AddScoped(typeof(IRepositoryBase<PurchaseGroup>), typeof(RepositoryBase<PurchaseGroup>));           
            services.AddScoped(typeof(IRepositoryBase<RequirmentPeriod>), typeof(RepositoryBase<RequirmentPeriod>));
            services.AddScoped(typeof(IRepositoryBase<ProcurementSection>), typeof(RepositoryBase<ProcurementSection>));
            services.AddScoped(typeof(IRepositoryBase<ProjectTaskMatrix>), typeof(RepositoryBase<ProjectTaskMatrix>));
            #endregion

            #region Operational
            services.AddScoped(typeof(IRepositoryBase<PurchaseRequisition>), typeof(RepositoryBase<PurchaseRequisition>));            
            services.AddScoped(typeof(IRepositoryBase<PRApprover >), typeof(RepositoryBase<PRApprover >));            
            services.AddScoped(typeof(IRepositoryBase<PRDelegateTeam>), typeof(RepositoryBase<PRDelegateTeam>));               
            services.AddScoped(typeof(IRepositoryBase<HotelAccommodation>), typeof(RepositoryBase<HotelAccommodation>));            
            services.AddScoped(typeof(IRepositoryBase<HARApprover >), typeof(RepositoryBase<HARApprover >));            
            services.AddScoped(typeof(IRepositoryBase<HARDelegateTeam>), typeof(RepositoryBase<HARDelegateTeam>));
            services.AddScoped(typeof(IRepositoryBase<Project>), typeof(RepositoryBase<Project>));
            services.AddScoped(typeof(IRepositoryBase<ProjectTeam>), typeof(RepositoryBase<ProjectTeam>));
            services.AddScoped(typeof(IRepositoryBase<RequestForDocument>), typeof(RepositoryBase<RequestForDocument>));
            services.AddScoped(typeof(IRepositoryBase<RequestForDocAttachment>), typeof(RepositoryBase<RequestForDocAttachment>));
            services.AddScoped(typeof(IRepositoryBase<RequestForDocumentApproval>), typeof(RepositoryBase<RequestForDocumentApproval>));
            services.AddScoped(typeof(IRepositoryBase<TechnicalEvaluation>), typeof(RepositoryBase<TechnicalEvaluation>));
            services.AddScoped(typeof(IRepositoryBase<TechnicalCriterion>), typeof(RepositoryBase<TechnicalCriterion>));
            services.AddScoped(typeof(IRepositoryBase<TechnicalCriteriaGroup>), typeof(RepositoryBase<TechnicalCriteriaGroup>));
            services.AddScoped(typeof(IRepositoryBase<FinancialCriteriaGroup>), typeof(RepositoryBase<FinancialCriteriaGroup>));
            services.AddScoped(typeof(IRepositoryBase<FinancialCriteria>), typeof(RepositoryBase<FinancialCriteria>));
            services.AddScoped(typeof(IRepositoryBase<FinancialHeaderValue>), typeof(RepositoryBase<FinancialHeaderValue>));
            services.AddScoped(typeof(IRepositoryBase<FinancialEvaluation>), typeof(RepositoryBase<FinancialEvaluation>));
            services.AddScoped(typeof(IRepositoryBase<HotelAccommodationCriteria>), typeof(RepositoryBase<HotelAccommodationCriteria>));
            services.AddScoped(typeof(IRepositoryBase<TenderInvitation>), typeof(RepositoryBase<TenderInvitation>));
            services.AddScoped(typeof(IRepositoryBase<FloatationSupplierFile>), typeof(RepositoryBase<FloatationSupplierFile>));
            services.AddScoped(typeof(IRepositoryBase<FinancialHeaders>), typeof(RepositoryBase<FinancialHeaders>));
            services.AddScoped(typeof(IRepositoryBase<TenderInvitationFloat>), typeof(RepositoryBase<TenderInvitationFloat>));
            services.AddScoped(typeof(IRepositoryBase<SupplierTenderInvitation>), typeof(RepositoryBase<SupplierTenderInvitation>));
            services.AddScoped(typeof(IRepositoryBase<ShortListApproval>), typeof(RepositoryBase<ShortListApproval>));
            services.AddScoped(typeof(IRepositoryBase<ShortListedSupplier>), typeof(RepositoryBase<ShortListedSupplier>));
            services.AddScoped(typeof(IRepositoryBase<StoredFiles>), typeof(RepositoryBase<StoredFiles>));
            services.AddScoped(typeof(IRepositoryBase<SuppliersProposalAttachment>), typeof(RepositoryBase<SuppliersProposalAttachment>));
            services.AddScoped(typeof(IRepositoryBase<SuppliersTenderProposal>), typeof(RepositoryBase<SuppliersTenderProposal>));
            services.AddScoped(typeof(IRepositoryBase<ProjectApproval>), typeof(RepositoryBase<ProjectApproval>));
            services.AddScoped(typeof(IRepositoryBase<Clarification>), typeof(RepositoryBase<Clarification>));
            services.AddScoped(typeof(IRepositoryBase<ProjectUpdateRecord>), typeof(RepositoryBase<ProjectUpdateRecord>));

            services.AddScoped(typeof(IRepositoryBase<TechnicalCriterionResult>), typeof(RepositoryBase<TechnicalCriterionResult>));
            services.AddScoped(typeof(IRepositoryBase<SuppliersTenderProposal>), typeof(RepositoryBase<SuppliersTenderProposal>));
            services.AddScoped(typeof(IRepositoryBase<TechnicalEvaluationResult>), typeof(RepositoryBase<TechnicalEvaluationResult>));
            services.AddScoped(typeof(IRepositoryBase<SupplierTechnicalEvaluationResult>), typeof(RepositoryBase<SupplierTechnicalEvaluationResult>));
            services.AddScoped(typeof(IRepositoryBase<FinancialEvaluationResult>), typeof(RepositoryBase<FinancialEvaluationResult>));
            services.AddScoped(typeof(IRepositoryBase<SupplierFinancialEvaluationResult>), typeof(RepositoryBase<SupplierFinancialEvaluationResult>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationSupplier>), typeof(RepositoryBase<NegotiationSupplier>));
            services.AddScoped(typeof(IRepositoryBase<Negotiation>), typeof(RepositoryBase<Negotiation>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationTeamApproval>), typeof(RepositoryBase<NegotiationTeamApproval>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationCommunication>), typeof(RepositoryBase<NegotiationCommunication>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationCommunicationHistory>), typeof(RepositoryBase<NegotiationCommunicationHistory>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationCommunicationHistoryAttachement>), typeof(RepositoryBase<NegotiationCommunicationHistoryAttachement>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationEvaluationResult>), typeof(RepositoryBase<NegotiationEvaluationResult>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationSupplierEvaluationResult>), typeof(RepositoryBase<NegotiationSupplierEvaluationResult>));
            services.AddScoped(typeof(IRepositoryBase<NegotiationCriterionResult>), typeof(RepositoryBase<NegotiationCriterionResult>));
            services.AddScoped(typeof(IRepositoryBase<SupplierResult>), typeof(RepositoryBase<SupplierResult>));
            services.AddScoped(typeof(IRepositoryBase<TenderInvitationFloat>), typeof(RepositoryBase<TenderInvitationFloat>));
            services.AddScoped(typeof(IRepositoryBase<ProjectUpdateRecord>), typeof(RepositoryBase<ProjectUpdateRecord>));
            services.AddScoped(typeof(IRepositoryBase<TechnicalResultMessage>), typeof(RepositoryBase<TechnicalResultMessage>));
            services.AddScoped(typeof(IRepositoryBase<ProjectCancelRequest>), typeof(RepositoryBase<ProjectCancelRequest>));
            services.AddScoped(typeof(IRepositoryBase<TechnicalEvaluationResultApproval>), typeof(RepositoryBase<TechnicalEvaluationResultApproval>));
            services.AddScoped(typeof(IRepositoryBase<TechnicalEvaluationApproval>), typeof(RepositoryBase<TechnicalEvaluationApproval>));
            services.AddScoped(typeof(IRepositoryBase<FinancialEvaluationApproval>), typeof(RepositoryBase<FinancialEvaluationApproval>));
            services.AddScoped(typeof(IRepositoryBase<FinancialEvaluationResultApproval>), typeof(RepositoryBase<FinancialEvaluationResultApproval>));
            #endregion

            #region report
            services.AddScoped(typeof(IRepositoryBase<ExcutiveSummary>), typeof(RepositoryBase<ExcutiveSummary>));
            services.AddScoped(typeof(IRepositoryBase<DetailEvaluationReport>), typeof(RepositoryBase<DetailEvaluationReport>));
            #endregion

            #region user managment
            services.AddScoped(typeof(IRepositoryBase<User>), typeof(RepositoryBase<User>));
			services.AddScoped(typeof(IRepositoryBase<UserToken>), typeof(RepositoryBase<UserToken>));
			services.AddScoped(typeof(IRepositoryBase<Privilege>), typeof(RepositoryBase<Privilege>));
			services.AddScoped(typeof(IRepositoryBase<RolePrivilege>), typeof(RepositoryBase<RolePrivilege>));
			services.AddScoped(typeof(IRepositoryBase<Role>), typeof(RepositoryBase<Role>));
			services.AddScoped(typeof(IRepositoryBase<ClientUser>), typeof(RepositoryBase<ClientUser>));
			services.AddScoped(typeof(IRepositoryBase<ClientUserToken>), typeof(RepositoryBase<ClientUserToken>));
			services.AddScoped(typeof(IRepositoryBase<ClientPrivilege>), typeof(RepositoryBase<ClientPrivilege>));
			services.AddScoped(typeof(IRepositoryBase<ClientRolePrivilege>), typeof(RepositoryBase<ClientRolePrivilege>));
			services.AddScoped(typeof(IRepositoryBase<ClientRole>), typeof(RepositoryBase<ClientRole>));
			services.AddScoped(typeof(IRepositoryBase<Menus>), typeof(RepositoryBase<Menus>));

            //
            services.AddScoped(typeof(IRepositoryBase<UserRole>), typeof(RepositoryBase<UserRole>));
            services.AddScoped(typeof(IRepositoryBase<Menu>), typeof(RepositoryBase<Menu>));

            //services.AddScoped(typeof(IRepositoryBase<User>), typeof(RepositoryBaseWork<User>));
            //services.AddScoped(typeof(IRepositoryBase<UserToken>), typeof(RepositoryBaseWork<UserToken>));
            //services.AddScoped(typeof(IRepositoryBase<Privilege>), typeof(RepositoryBaseWork<Privilege>));
            //services.AddScoped(typeof(IRepositoryBase<RolePrivilege>), typeof(RepositoryBaseWork<RolePrivilege>));
            //services.AddScoped(typeof(IRepositoryBase<Role>), typeof(RepositoryBaseWork<Role>));
            //services.AddScoped(typeof(IRepositoryBase<UserRole>), typeof(RepositoryBaseWork<UserRole>));
            //services.AddScoped(typeof(IRepositoryBase<Menu>), typeof(RepositoryBaseWork<Menu>));
            //services.AddScoped(typeof(IRepositoryBase<PasswordRecovery>), typeof(RepositoryBaseWork<PasswordRecovery>));
            //services.AddScoped(typeof(IRepositoryBase<EmailTemplate>), typeof(RepositoryBaseWork<EmailTemplate>));

            #endregion

            #region common
            services.AddScoped(typeof(IRepositoryBase<AccountSubscription>), typeof(RepositoryBase<AccountSubscription>));
			services.AddScoped(typeof(IRepositoryBase<PasswordService>), typeof(RepositoryBase<PasswordService>));
			services.AddScoped(typeof(IRepositoryBase<EmailTemplate>), typeof(RepositoryBase<EmailTemplate>));
			services.AddScoped(typeof(IRepositoryBase<MasterDataTransactionalHistory>), typeof(RepositoryBase<MasterDataTransactionalHistory>));
			#endregion		

			#region subscription
			services.AddScoped(typeof(IRepositoryBase<AccountSubscription>), typeof(RepositoryBase<AccountSubscription>));
			//services.AddScoped(typeof(IRepositoryBase<AccountSubscriptionUser>), typeof(MasterRepositoryBase<AccountSubscriptionUser>));
			services.AddScoped(typeof(IRepositoryBase<PasswordRecovery>), typeof(RepositoryBase<PasswordRecovery>));
			#endregion

		}
	}
}