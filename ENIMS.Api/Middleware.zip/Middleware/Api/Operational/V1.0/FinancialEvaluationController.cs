﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class FinancialEvaluationController : ControllerBase
    {
        private readonly IFinancialEvaluation<FinancialResultResponse, FinancialResultDetailResponse> _evaluation;
        private readonly ILoggerManager _logger;
        private readonly IProjectsProcess _projectProcess;
        private readonly IEvaluation<FinancialEvaluationResponse, FinancialEvaluationsResponse, FinancialEvaluationRequest, FinancialEvaluationUpdateRequest> _financialEvaluationRepository;
        public FinancialEvaluationController(ILoggerManager logger, IEvaluation<FinancialEvaluationResponse, FinancialEvaluationsResponse, FinancialEvaluationRequest,
            FinancialEvaluationUpdateRequest> financialEvaluationRepository, IFinancialEvaluation<FinancialResultResponse, FinancialResultDetailResponse> evaluation,
            IProjectsProcess projectProcess)
        {
            _financialEvaluationRepository = financialEvaluationRepository;
            _projectProcess = projectProcess;
            _evaluation = evaluation;
            _logger = logger;
        }
        [HttpPost(nameof(Create))]
        public async Task<ActionResult<FinancialEvaluationResponse>> Create([FromBody] FinancialEvaluationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.FinancialCriteria, request.ProjectId);
            if (validation.PerformTask)
            {
                var result = await _financialEvaluationRepository.CreateAsync(request);
                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.FinancialCriteria, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpGet(nameof(GetByParentId))]
        public FinancialEvaluationResponse GetByParentId(long id)
        {
            return _financialEvaluationRepository.GetByParentId(id);
        }
        [HttpGet(nameof(GetById))]
        public FinancialEvaluationResponse GetById(long id)
        {
            return _financialEvaluationRepository.GetById(id);
        }
        [HttpDelete(nameof(Delete))]
        public async Task<OperationStatusResponse> Delete(long id)
        {
            return await _financialEvaluationRepository.Delete(id);
        }
        [HttpPut(nameof(Update))]
        public async Task<FinancialEvaluationResponse> Update(FinancialEvaluationUpdateRequest request)
        {
            return await _financialEvaluationRepository.Update(request);
        }
        [HttpGet(nameof(GetFinancialEvaluationResult))]
        public FinancialResultResponse GetFinancialEvaluationResult(long id)
        {
            return _evaluation.GetSuppliersResult(id);
        }
        [HttpPost(nameof(Evaluate))]
        public async Task<ActionResult<FinancialResultResponse>> Evaluate([FromBody] SupplierFinancialEvaluationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.FinancialEvaluation, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _evaluation.Evaluate(request);

                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.FinancialEvaluation, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpPost(nameof(CalculateNetPrice))]
        public async Task<ActionResult<FinancialResultResponse>> CalculateNetPrice([FromBody] NetPriceRequest request)
        {
            var result = await _evaluation.SetNetPrice(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpGet(nameof(GetEvaluationDetail))]
        public FinancialResultDetailResponse GetEvaluationDetail(long id)
        {
            return _evaluation.GetEvaluationDetail(id);
        }
        [HttpGet(nameof(GetEvaluationDetailByProject))]
        public FinancialResultDetailResponse GetEvaluationDetailByProject(long supplierId, long projectId)
        {
            return _evaluation.GetEvaluationDetail(supplierId, projectId);
        }
        [HttpPut(nameof(UpdateEvaluation))]
        public async Task<FinancialResultResponse> UpdateEvaluation(SupplierFinancialEvaluationUpdateRequest request)
        {
            return await _evaluation.UpdateFinancialEvaluaton(request);
        }

        [HttpPost(nameof(ApproveFinancialEvaluation))]
        public async Task<ActionResult<OperationStatusResponse>> ApproveFinancialEvaluation(ApprovalRequest request)
        {
            var result = _evaluation.ApproveFinancialEvaluation(request.ProjectId);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpPost(nameof(ApproveFinancialCriteria))]
        public async Task<ActionResult<OperationStatusResponse>> ApproveFinancialCriteria(ApprovalRequest request)
        {
            var result = _financialEvaluationRepository.ApproveCriteria(request.ProjectId);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
    }
}
