﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.RequestModel.Operational.Negotiation;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Common.ResponseModel.Operational.Negotiation;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class NegotiationCommunicationController : ControllerBase
    {
        private readonly INegotiationCommunication _nc;
        private readonly IProjectsProcess _projectProcess;
        private IHttpContextAccessor _httpContextAccessor;

        public NegotiationCommunicationController(INegotiationCommunication nc, IProjectsProcess projectProcess, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _projectProcess = projectProcess;
            _nc = nc;
        }

        [HttpPost(nameof(CreateSubject))]
        [ProducesResponseType(statusCode: 400)]
        [ProducesResponseType(statusCode: 201)]
        [ProducesResponseType(statusCode: 500)]
        public async Task<IActionResult> CreateSubject([FromBody] CreatNegotiatonSubjectRequest request)
        {
            var ProjectId = _httpContextAccessor.HttpContext.Request.Headers["ProjectId"].ToString();

            if (ProjectId != null)
            {
                long.TryParse(ProjectId, out long projectId);

                var validation = _projectProcess.CheckProcess(ProjectTask.NegotiationCommunication, projectId);

                if (validation.PerformTask)
                {
                    if (!ModelState.IsValid)
                        return BadRequest(ModelState);

                    var result = await _nc.CreateSubjects(request);

                    if (result.Status == OperationStatus.SUCCESS)
                    {
                        _projectProcess.ChangeProcessStage(ProjectTask.NegotiationCommunication, projectId);
                        return StatusCode(201, result);
                    }
                    else
                        return StatusCode(500, result);
                }
                else
                    return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
            else
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = "Project id not found." });
        }


        [HttpPost(nameof(SendNegotiationMessage))]
        [ProducesResponseType(statusCode: 400)]
        [ProducesResponseType(statusCode: 201)]
        [ProducesResponseType(statusCode: 500)]
        public async Task<ActionResult<NegotiationCommunicatonResponse>> SendNegotiationMessage([FromForm] SendMessageRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var result = await _nc.SendNegotiationMessage(request);
            if (result.Status == OperationStatus.SUCCESS)
            {
                //var response = _nc.GetNegotiationMessage(request.Id);
                return Ok(result);
            }
            else
                return StatusCode(500, result);
        }
        [HttpPost(nameof(SendNegotiationMessageSupplier))]
        [ProducesResponseType(statusCode: 400)]
        [ProducesResponseType(statusCode: 201)]
        [ProducesResponseType(statusCode: 500)]
        public async Task<IActionResult> SendNegotiationMessageSupplier([FromForm] SendMessageRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var result = await _nc.SendNegotiationMessageSupplier(request);
            if (result.Status == OperationStatus.SUCCESS)
                return StatusCode(201, result);
            else
                return StatusCode(500, result);
        }


        [HttpGet(nameof(GetNegotiationMessage))]
        public NegotiationCommunicatonResponse GetNegotiationMessage(long id)
        {
            return _nc.GetNegotiationMessage(id);
        }


        [HttpGet(nameof(GetGroupedNegotiationMessage))]
        public GroupedNegotiationCommunicationResponse GetGroupedNegotiationMessage()
        {
            return _nc.GetGroupedNegotiationMessage();
        }
    }
}

