﻿using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class ApprovalController : ControllerBase
    {
        private readonly IApproval _approval;     
        public ApprovalController(IApproval approval)
        {
            _approval = approval;
        }
        [HttpGet(nameof(GetApprovers))]
        public ApprovalParticipant GetApprovers(string fileName)
        {
            return _approval.GetApproversName(fileName);

        }

        [HttpPost(nameof(UpdateApprovalStatus))]
        public Task<bool> UpdateApprovalStatus(ApprovalStatusRequest approvalStatusRequest)
        {
            return _approval.UpdateApprovalStatus(approvalStatusRequest);

        }
    }
}
