﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Operational.V1._0
{

    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class ResultController : ControllerBase
    {
        private readonly IProjectsProcess _projectProcess;
        private readonly IResult _result;
        public ResultController(IResult result, IProjectsProcess projectProcess)
        {
            _projectProcess = projectProcess;
            _result = result;
        }

        [HttpPost(nameof(Save))]
        public async Task<ActionResult<OperationStatusResponse>> Save(SupplierResultRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.ResultNotification, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _result.Save(request);
                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.ResultNotification, request.ProjectId);

                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        
        [HttpPut(nameof(Update))]
        public async Task<ActionResult<OperationStatusResponse>> Update(SupplierResultUpdateRequest request)
        {
            var result = await _result.Update(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }

        [HttpGet(nameof(Detail))]
        public SupplierResultResponse Detail(long projectId, long supplierId)
        {
           var request= new ResultNotificationDetailRequest { ProjectId = projectId, SupplierId = supplierId }; 
            return _result.Detail(request);
        }
        
        [HttpGet(nameof(Send))]
        public OperationStatusResponse Send(long Id)
        {
            return _result.Send(Id);
        }

        [HttpDelete(nameof(Delete))]
        public OperationStatusResponse Delete(long Id)
        {
            return _result.Delete(Id);
        }


    }
}
