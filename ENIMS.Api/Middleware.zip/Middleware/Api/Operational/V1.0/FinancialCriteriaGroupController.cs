﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using EProcurement.Core.Interface.Operational;
using EProcurement.Core.Interface.Helper;
using Microsoft.AspNetCore.Http;

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class FinancialCriteriaGroupController : ControllerBase
    {
        private readonly IProjectsProcess _projectProcess;
        private IHttpContextAccessor _httpContextAccessor;

        private readonly ILoggerManager _logger;
        private readonly ICrud<FinancialCriteriaGroupResponse, FinancialCriteriaGroupsResponse, FinancialCriteriaGroupRequest, FinancialCriteriaGroupUpdateRequest> _financialCriteriaGroupRepository;
        public FinancialCriteriaGroupController(ILoggerManager logger, ICrud<FinancialCriteriaGroupResponse, FinancialCriteriaGroupsResponse, FinancialCriteriaGroupRequest, FinancialCriteriaGroupUpdateRequest> financialCriteriaGroupRepository, IProjectsProcess projectProcess, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
               _projectProcess = projectProcess;
            _financialCriteriaGroupRepository = financialCriteriaGroupRepository;
            _logger = logger;
        }

        [HttpPost(nameof(Create))]
        public async Task<ActionResult<FinancialCriteriaGroupResponse>> Create([FromBody] FinancialCriteriaGroupRequest request)
        {
            var ProjectId = _httpContextAccessor.HttpContext.Request.Headers["ProjectId"].ToString();

            if (ProjectId != null)
            {
                long.TryParse(ProjectId, out long projectId);

                var validation = _projectProcess.CheckProcess(ProjectTask.FinancialCriteria, projectId);

                if (validation.PerformTask)
                {
                    var result = await _financialCriteriaGroupRepository.CreateAsync(request);
                    if (result.Status == OperationStatus.SUCCESS)
                    {
                        _projectProcess.ChangeProcessStage(ProjectTask.FinancialCriteria, projectId);
                        return Ok(result);
                    }
                    else
                        return StatusCode(500, result);
                }
                else
                {
                    return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
                }
            }
            else
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = "Project id not found." });
        }
        [HttpGet(nameof(GetByParentId))]
        public FinancialCriteriaGroupsResponse GetByParentId(long id)
        {
            return _financialCriteriaGroupRepository.GetByParentId(id);
        }
        [HttpGet(nameof(GetById))]
        public FinancialCriteriaGroupResponse GetById(long id)
        {
            return _financialCriteriaGroupRepository.GetById(id);
        }
        [HttpDelete(nameof(Delete))]
        public async Task<OperationStatusResponse> Delete(long id)
        {
            return await _financialCriteriaGroupRepository.Delete(id);
        }
        [HttpPut(nameof(Update))]
        public async Task<FinancialCriteriaGroupResponse> Update(FinancialCriteriaGroupUpdateRequest request)
        {
            return await _financialCriteriaGroupRepository.Update(request);
        }
    }
}

