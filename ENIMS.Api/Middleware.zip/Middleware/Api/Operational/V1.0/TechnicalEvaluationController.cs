﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class TechnicalEvaluationController : ControllerBase
    {
        private readonly ILoggerManager _logger;
        private readonly IProjectsProcess _projectProcess;
        private readonly ITechnicalEvaluation _evaluation;
        private readonly IEvaluation<TechnicalEvaluationResponse, TechnicalEvaluationsResponse, TechnicalEvaluationRequest, TechnicalEvaluationUpdateRequest> _technicalEvaluationRepository;
        public TechnicalEvaluationController(ILoggerManager logger, IEvaluation<TechnicalEvaluationResponse, TechnicalEvaluationsResponse, TechnicalEvaluationRequest, TechnicalEvaluationUpdateRequest> technicalEvaluationCrud,
            ITechnicalEvaluation evaluation, IProjectsProcess projectProcess)
        {
            _technicalEvaluationRepository = technicalEvaluationCrud;
            _projectProcess = projectProcess;
            _evaluation = evaluation;
            _logger = logger;
        }
        [HttpPost(nameof(Create))]
        public async Task<ActionResult<TechnicalEvaluationResponse>> Create([FromBody] TechnicalEvaluationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.TechnicalCriteria, request.ProjectId);
            if (validation.PerformTask)
            {
                var result = await _technicalEvaluationRepository.CreateAsync(request);
                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.TechnicalCriteria, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpGet(nameof(GetByParentId))]
        public TechnicalEvaluationResponse GetByParentId(long id)
        {
            return _technicalEvaluationRepository.GetByParentId(id);
        }
        [HttpGet(nameof(GetById))]
        public TechnicalEvaluationResponse GetById(long id)
        {
            return _technicalEvaluationRepository.GetById(id);
        }
        [HttpDelete(nameof(Delete))]
        public async Task<OperationStatusResponse> Delete(long id)
        {
            return await _technicalEvaluationRepository.Delete(id);
        }
        [HttpPut(nameof(Update))]
        public async Task<TechnicalEvaluationResponse> Update(TechnicalEvaluationUpdateRequest request)
        {
            return await _technicalEvaluationRepository.Update(request);
        }
        [HttpGet(nameof(GetTechnicalEvaluationResult))]
        public TechnicalResultResponse GetTechnicalEvaluationResult(long id)
        {
            return _evaluation.GetSuppliersResult(id);
        }
        [HttpGet(nameof(GetTechnicalEvaluationDetail))]
        public TechnicalResultDetailResponse GetTechnicalEvaluationDetail(long projectId, long supplierResultId)
        {
            var request = new SupplierResultDetailRequest() { ProjectId = projectId, SupplierResultId = supplierResultId };
            return _evaluation.GetEvaluationDetail(request);
        }
        [HttpPost(nameof(Evaluate))]
        public async Task<ActionResult<TechnicalResultResponse>> Evaluate([FromBody] SupplierTechnicalEvaluationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.TechnicalEvaluation, request.ProjectId);
            if (validation.PerformTask)
            {
                var result = await _evaluation.Evaluate(request);

                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.TechnicalEvaluation, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpPost(nameof(NotifyResult))]
        public async Task<ActionResult<OperationStatusResponse>> NotifyResult([FromBody] NotifySupplierResultRequest request)
        {
            var result = _evaluation.NotifySupplierResult(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpGet(nameof(EnableFinancialEvaluation))]
        public async Task<ActionResult<OperationStatusResponse>> EnableFinancialEvaluation(long id)
        {
            var result = _evaluation.EnableFinancialEvaluation(id);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpPost(nameof(ApproveTechnicalEvaluation))]
        public async Task<ActionResult<OperationStatusResponse>> ApproveTechnicalEvaluation(ApprovalRequest request)
        {
            var result = _evaluation.ApproveTechnicalEvaluation(request.ProjectId  );
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpPut(nameof(UpdateTechnicalCriteriaResult))]
        public async Task<CriteriaResultResponse> UpdateTechnicalCriteriaResult(CritreaResultUpdateRequest request)
        {
            return await _evaluation.UpateTechnicalCriteriaResult(request);
        }
        [HttpPut(nameof(UpdateEvaluation))]
        public async Task<TechnicalResultResponse> UpdateEvaluation(SupplierTechnicalEvaluationUpdateRequest request)
        {
            return await _evaluation.UpdateEvaluation(request);
        }
        [HttpGet(nameof(GetTechnicalResultMessage))]
        public TechnicalResultMessageResponse GetTechnicalResultMessage(long projectId, long SupplierId)
        {
            var request = new TechnicalResultMessageRequest() { ProjectId = projectId, SupplierId = SupplierId };
            return _evaluation.GetTechnicalResultMessage(request);
        }
        [HttpGet(nameof(IgnoreTechnicalEvaluation))]
        public async Task<ActionResult<OperationStatusResponse>> IgnoreTechnicalEvaluation(long id)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.TechnicalCriteria, id);
            if (validation.PerformTask)
            {
                var result = _technicalEvaluationRepository.IgnoreTechnicalEvaluation(id).Result;
                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.TechnicalCriteria, id);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpPost(nameof(ApproveTechnicalCriteria))]
        public async Task<ActionResult<OperationStatusResponse>> ApproveTechnicalCriteria(ApprovalRequest request)
        {
            var result = _technicalEvaluationRepository.ApproveCriteria(request.ProjectId);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }

    }
}
