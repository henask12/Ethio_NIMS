﻿using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class NotificationController : ControllerBase
    {
        private readonly INotificaton _notificaton;
        public NotificationController(INotificaton notificaton)
        {
            _notificaton = notificaton;
        }
        [HttpGet(nameof(GetNotifications))]
        public NotificationResponse GetNotifications()
        {
            return _notificaton.GetNotifications();

        }
        [HttpGet(nameof(GetClarificationNotifications))]
        public ClarificationNotificationResponse GetClarificationNotifications(long projectId)
        {
            return _notificaton.GetClarificationNotificationBackOffice(projectId);
        }
        [HttpPost(nameof(UpdateNotification))]
        public void UpdateNotification(UpdateNotificationRequest request)
        {
            _notificaton.UpdateNotification(request);

        }
    }
}
