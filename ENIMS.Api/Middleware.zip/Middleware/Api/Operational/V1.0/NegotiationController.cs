﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class NegotiationController : ControllerBase
    {
        private readonly INegotiation _negotiation;
        private readonly IProjectsProcess _projectProcess;
        public NegotiationController(INegotiation negotiation, IProjectsProcess projectProcess)
        {
            _projectProcess = projectProcess;
            _negotiation = negotiation;
        }

        [HttpPost(nameof(SelectSuppliers))]
        public async Task<ActionResult<NegotiationSupplierResponses>> SelectSuppliers([FromBody] NegotiationSupplierRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.EvaluationResult, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _negotiation.SelectSupplier(request);

                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.EvaluationResult, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }

        [HttpGet(nameof(GetNegotiationSuppliers))]
        public NegotiationSupplierResponses GetNegotiationSuppliers(long id)
        {
            return _negotiation.GetNegotiationSuppliers(id);
        }
        [HttpPost(nameof(CreateNegotiatonTeam))]
        [ProducesResponseType(statusCode: 200)]
        [ProducesResponseType(statusCode: 400)]
        [ProducesResponseType(statusCode: 401)]
        public async Task<IActionResult> CreateNegotiatonTeam(NegotiationTeamFormationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.NegotiationTeamFormation, request.ProjectId);

            if (validation.PerformTask)
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var result = _negotiation.CreateNegotiatonTeam(request).Result;
                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.NegotiationTeamFormation, request.ProjectId);
                    return Ok(result);
                }

                return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }

        [HttpGet(nameof(GetNegotiationTeam))]
        public NegotiationTeamResponse GetNegotiationTeam(long id)
        {
            return _negotiation.GetNegotiationTeam(id);
        }
    }
}

