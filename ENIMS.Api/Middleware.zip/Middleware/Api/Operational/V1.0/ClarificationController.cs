﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Operational.V1._0
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClarificationController : Controller
    {
        private readonly ILoggerManager _logger;
        private readonly IUserService _userService;
        private readonly IClarification _clarificationService;
        public ClarificationController(ILoggerManager logger, IClarification clarificationService, IUserService userService)
        {
            _logger = logger;
            _userService = userService;
            _clarificationService = clarificationService;
        }

        [HttpPost(nameof(SaveClarification))]
        public async Task<ActionResult<ClarificationResponse>> SaveClarification(ClarificationRequest request)
        {
            var result = await _clarificationService.SaveClarification(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);

        }


        [HttpGet(nameof(RetrieveClarification))]
        public ClarificationResponse RetrieveClarification(long? id)
        {

            return _clarificationService.RetrieveClarification(id);
      
        }
        
    }
}
