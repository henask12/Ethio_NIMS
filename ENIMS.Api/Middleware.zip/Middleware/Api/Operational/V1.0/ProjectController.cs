﻿using EProcurement.Common;
using EProcurement.Common.Helper;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Core;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Operational.V1._0
{

    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class ProjectController : Controller
    {
        private IHttpContextAccessor _httpContextAccessor;

        private readonly IProjectsProcess _projectProcess;
        private readonly ILoggerManager _logger;
        private readonly IUserService _userService;
        private readonly IProject<ProjectInitiationResponse, ProjectInitiationsResponse, ProjectInitiationRequest> _project;
        private readonly ITenderInvitation<TenderInvitationResponse, TenderInvitationRequest> _tenderInvitation;
        public ProjectController(IProject<ProjectInitiationResponse, ProjectInitiationsResponse, ProjectInitiationRequest> project, ILoggerManager logger,
            ITenderInvitation<TenderInvitationResponse, TenderInvitationRequest> tenderInvitation, IUserService userService, IProjectsProcess projectProcess, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _project = project;
            _userService = userService;
            _projectProcess = projectProcess;
            _tenderInvitation = tenderInvitation;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpPost(nameof(Initiate))]
        public async Task<ActionResult<ProjectInitiationResponse>> Initiate([FromBody] ProjectInitiationRequest request)
        {
            var result = await _project.Initiate(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }

        [HttpPost(nameof(AssignProcessType))]
        public async Task<ActionResult<ProjectInitiationResponse>> AssignProcessType([FromBody] PurchaseProcessTypeRequisition request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.PurchaseMethodSelection, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _project.AssignProcessType(request);

                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.PurchaseMethodSelection, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
        }

        [HttpGet(nameof(GetMyProjects))]
        public ProjectInitiationsResponse GetMyProjects()
        {
            return _project.GetMyProjects();
        }

        [HttpGet(nameof(GetAll))]
        public ProjectInitiationsResponse GetAll()
        {
            return _project.GetAll();
        }

        [HttpGet(nameof(GetMyPurchaseProjects))]
        public ProjectInitiationsResponse GetMyPurchaseProjects()
        {
            return _project.GetMyPurchaseProjects();
        }

        [HttpGet(nameof(GetMyHotelAccommodationProjects))]
        public ProjectInitiationsResponse GetMyHotelAccommodationProjects()
        {
            return _project.GetMyHotelAccommodationProjects();
        }

        [HttpGet(nameof(GetAllHotelAccommodationProjects))]
        public ProjectInitiationsResponse GetAllHotelAccommodationProjects()
        {
            return _project.GetAllHotelAccommodationProjects();
        }
        [HttpGet(nameof(GetAllPurchaseProjects))]
        public ProjectInitiationsResponse GetAllPurchaseProjects()
        {
            return _project.GetAllPurchaseProjects();
        }

        [HttpGet(nameof(GetById))]
        public ProjectInitiationResponse GetById(long Id)
        {
            return _project.GetById(Id);
        }
        [HttpGet(nameof(GetProjectOverview))]
        public ProjectOverviewResponse GetProjectOverview(long Id)
        {
            return _project.GetProjectOverview(Id);
        }

        [HttpPut(nameof(DefineBidClosing))]
        public async Task<ProjectInitiationResponse> DefineBidClosing(BidClosingRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.DefineBidTime, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _project.DefineBidClosing(request);

                if (result.Status == OperationStatus.SUCCESS)
                    _projectProcess.ChangeProcessStage(ProjectTask.DefineBidTime, request.ProjectId);

                return result;
            }

            return new ProjectInitiationResponse
            {
                Status = OperationStatus.ERROR,
                Message = "Invalid action sequence"
            };
        }

        [HttpPost(nameof(InviteTender))]
        public async Task<ActionResult<TenderInvitationResponse>> InviteTender(TenderInvitationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.TenderInvitation, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _tenderInvitation.Invite(request);

                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.TenderInvitation, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }

            return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
        }

        [HttpPut(nameof(ExpressInterestOnOpenBid))]
        public async Task<ActionResult<TenderInvitationResponse>> ExpressInterestOnOpenBid(BidInterestRequest request)
        {
            var result = await _tenderInvitation.ExpressInterestOnOpenBid(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpPut(nameof(ExpressInterestOnInvitationBid))]
        public async Task<ActionResult<TenderInvitationResponse>> ExpressInterestOnInvitationBid(BidInterestRequest request)
        {
            var result = await _tenderInvitation.ExpressInterestOnInvitationdBid(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpGet(nameof(GetOpenBids))]
        public PostedBidsResponse GetOpenBids()
        {
            return _tenderInvitation.GetPostedBids();
        }
        [HttpPut(nameof(UpdatePostedBids))]
        public InvitationResponse UpdatePostedBids(TenderInvitationRequest tenderInvitationRequest)
        {
            return _tenderInvitation.UpdatePostedBids(tenderInvitationRequest);
        }
        [HttpGet(nameof(GetOpenBidsInternal))]
        public PostedBidsResponse GetOpenBidsInternal()
        {
            return _tenderInvitation.GetOpenBidsInternal();
        }
        [HttpGet(nameof(GetInvitationBids))]
        public PostedBidsResponse GetInvitationBids()
        {
            return _tenderInvitation.GetInvitationBids();
        }
        [HttpGet(nameof(ShowBidInterests))]
        public SupplierTenderInvitationResponse ShowBidInterests(long Id)
        {
            return _tenderInvitation.ShowBidInterests(Id);
        }       
        [HttpPost(nameof(ShortListSuppliers))]
        public async Task<ActionResult<bool>> ShortListSuppliers(ShortListRequest request)
        {
            var ProjectId = _httpContextAccessor.HttpContext.Request.Headers["ProjectId"].ToString();

            if (ProjectId != null)
            {
                long.TryParse(ProjectId, out long projectId);

                var validation = _projectProcess.CheckProcess(ProjectTask.ShortListing, projectId);

                if (validation.PerformTask)
                {
                    var result = await _tenderInvitation.ShortListSupplier(request);
                    if (result.Status == OperationStatus.SUCCESS)
                    {
                        _projectProcess.ChangeProcessStage(ProjectTask.ShortListing, projectId);
                        return Ok(result);
                    }
                    else
                        return StatusCode(500, result);
                }
                else
                {
                    return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
                }
            }
            else
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = "Project id not found." });
        }
        [HttpGet(nameof(GetShortListedSuppliers))]
        public ShortListedResponses GetShortListedSuppliers(long projectId)
        {
            return _tenderInvitation.GetShortListedSuppliers(projectId);
        }
        [HttpPost(nameof(FloatRequestDocument))]
        public async Task<ActionResult<SupplierTenderInvitationResponse>> FloatRequestDocument(DocumentFloationRequest request)
        {
            var ProjectId = _httpContextAccessor.HttpContext.Request.Headers["ProjectId"].ToString();

            if (ProjectId != null)
            {
                long.TryParse(ProjectId, out long projectId);

                var validation = _projectProcess.CheckProcess(ProjectTask.DocumentFlotation, projectId);

                if (validation.PerformTask)
                {
                    var result = await _tenderInvitation.FloatRequestDocument(request);
                    if (result.Status == OperationStatus.SUCCESS)
                    {
                        _projectProcess.ChangeProcessStage(ProjectTask.DocumentFlotation, projectId);
                        return Ok(result);
                    }
                    else
                        return StatusCode(500, result);
                }
                else
                    return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
            else
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = "Project id not found." });

        }
        [HttpGet(nameof(GetProposals))]
        public ProposalResponses GetProposals()
        {
            return _tenderInvitation.GetProposals();
        }
        [HttpPost(nameof(SubmitProposal))]
        public async Task<ActionResult<SupplierTenderInvitationResponse>> SubmitProposal([FromForm] SubmitProposalRequest request)
        {
            var result = await _tenderInvitation.SubmitProposal(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpGet(nameof(GetSubmitedProposal))]
        public SubmitedPropsalResponse GetSubmitedProposal(long Id)
        {
            return _tenderInvitation.GetSubmitedProposal(Id);
        }
       
        [HttpGet(nameof(GetInvitationPreRequisite))]
        public InvitationResponse GetInvitationPreRequisite(long id)
        {
            return _tenderInvitation.GetInvitationPreRequisite(id);
        }
        [HttpGet(nameof(GetMyAppliedTenders))]
        public PostedBidsResponse GetMyAppliedTenders()
        {
            return _tenderInvitation.GetMyAppliedTenders();
        }
        [HttpGet(nameof(GetCombinedSumResult))]
        public CombinedSumResponse GetCombinedSumResult(long Id)
        {
            return _project.GetCombinedSumResult(Id);
        }
        [HttpGet(nameof(GetNegotiationCombinedSumResult))]
        public CombinedSumResponse GetNegotiationCombinedSumResult(long Id)
        {
            return _project.GetNegotiationCombinedSumResult(Id);
        }
        [HttpGet(nameof(IsProjectDocumentFloated))]
        public FloatationResponse IsProjectDocumentFloated(long Id)
        {
            return _project.IsProjectDocumentFloated(Id);
        }
        [HttpPut(nameof(UpdateBidClosing))]
        public async Task<ActionResult<OperationStatusResponse>> UpdateBidClosing(BidClosingUpdatRequest request)
        {
            var result = await _project.UpdateBidClosing(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpGet(nameof(GetResult))]
        public ResultMessageResponses GetResult()
        {
            return _tenderInvitation.GetResult();
        }
        [HttpGet(nameof(GetProjectTasks))]
        public ProjectProcessTaskResponse GetProjectTasks(long Id)
        {
            return _projectProcess.GetProjectTaskMatrix(Id);
        }
        [HttpPost(nameof(CancelProject))]
        public async  Task<ActionResult<OperationStatusResponse>> CancelProject([FromForm]ProjectCancelationRequest request)
        {
            var result =  _project.CancelProject(request).Result;
            if (result.Status == OperationStatus.SUCCESS)       
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpGet(nameof(GetProjectCancelRequest))]
        public ProjectCancelationResponse GetProjectCancelRequest(long Id)
        {
            return _project.GetCancelRequest(Id);
        }
    }
}
