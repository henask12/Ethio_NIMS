﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Operational;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Common.ResponseModel.Operational.Negotiation;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Operational;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Operational.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class NegotiationEvaluationController : ControllerBase
    {
        private readonly IProjectsProcess _projectProcess;
        private readonly IFinancialEvaluation<FinancialResultResponse, NegotiationResultDetailResponse> _evaluation;
        public NegotiationEvaluationController(IFinancialEvaluation<FinancialResultResponse, NegotiationResultDetailResponse> evaluation, IProjectsProcess projectProcess)
        {
            _projectProcess = projectProcess;
            _evaluation = evaluation;
        }

        [HttpPost(nameof(Evaluate))]
        public async Task<ActionResult<FinancialResultResponse>> Evaluate([FromBody] SupplierFinancialEvaluationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.NegotiationEvaluation, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _evaluation.Evaluate(request);
                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.NegotiationEvaluation, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpPost(nameof(CalculateNetPrice))]
        public async Task<ActionResult<FinancialResultResponse>> CalculateNetPrice([FromBody] NetPriceRequest request)
        {
            var result = await _evaluation.SetNetPrice(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
        [HttpGet(nameof(GetEvaluationDetail))]
        public NegotiationResultDetailResponse GetEvaluationDetail(long id)
        {
            return _evaluation.GetEvaluationDetail(id);
        }
        [HttpGet(nameof(GetEvaluationDetailByProject))]
        public NegotiationResultDetailResponse GetEvaluationDetailByProject(long supplierId, long projectId)
        {
            return _evaluation.GetEvaluationDetail(supplierId, projectId);
        }
        [HttpGet(nameof(GetNegotiationEvaluationResult))]
        public FinancialResultResponse GetNegotiationEvaluationResult(long id)
        {
            return _evaluation.GetSuppliersResult(id);
        }
    }
}
