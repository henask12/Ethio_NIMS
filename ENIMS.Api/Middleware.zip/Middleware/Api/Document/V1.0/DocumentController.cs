﻿using EProcurement.Common;
using EProcurement.Core.Interface.Helper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Document.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class DocumentController : ControllerBase
    {
        private readonly IFileHelper _fileHelper;
        public DocumentController(IFileHelper fileHelper)
        {
            _fileHelper = fileHelper;
        }
        [HttpGet(nameof(Download))]
        public async Task<ActionResult> Download(string fileName)
        {
            var result = await _fileHelper.Download( fileName);
            if (result.Status == OperationStatus.SUCCESS)
                return File(result.FileMemoryStream.ToArray(), result.ContentType);
            else
                return StatusCode(500);
        }
        [HttpGet(nameof(DownloadBackOffice))]
        public async Task<ActionResult<DownloadResponse>> DownloadBackOffice(string fileName)
        {
            var result = await _fileHelper.Download(fileName);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(new DownloadResponse { FileContent = result.FileMemoryStream.ToArray(), ContentType = result.ContentType, GetFileName = result.GetFileName }) ;
            else
                return StatusCode(500,result);
        }
        [HttpGet(nameof(DownloadTechnical))]
        public async Task<ActionResult> DownloadTechnical(string fileName, long projectId)
        {
            var result = await _fileHelper.DownloadTechnical(fileName, projectId);
            if (result.Status == OperationStatus.SUCCESS)
                return File(result.FileMemoryStream.ToArray(), result.ContentType);
            else
                return StatusCode(500,result);
        }
        [HttpGet(nameof(DownloadFinancial))]
        public async Task<ActionResult> DownloadFinancial(string fileName, long projectId)
        {
            var result = await _fileHelper.DownloadFinancial(fileName, projectId);
            if (result.Status == OperationStatus.SUCCESS)
                return File(result.FileMemoryStream.ToArray(), result.ContentType);
            else
                return StatusCode(500, result);
        }

    }
}
