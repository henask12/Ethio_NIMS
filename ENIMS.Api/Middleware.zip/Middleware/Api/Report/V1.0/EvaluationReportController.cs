﻿using EProcurement.Common;
using EProcurement.Common.RequestModel.Report;
using EProcurement.Common.ResponseModel.Operational;
using EProcurement.Common.ResponseModel.Report;
using EProcurement.Core.Interface.Helper;
using EProcurement.Core.Interface.Report;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace EProcurement.Api.Api.Report.V1._0
{
    [ApiController]
    [Route("api/V1.0/[controller]")]
    public class EvaluationReportController : ControllerBase
    {
        private readonly IReport _report;
        private readonly IProjectsProcess _projectProcess;

        public EvaluationReportController(IReport report, IProjectsProcess projectProcess)
        {
            _projectProcess = projectProcess;
            _report = report;
        }

        [HttpGet(nameof(OverallProjectReport))]
        public OverallProjectReportResponse OverallProjectReport(long Id)
        {
            return _report.GetOverallProjectReport(Id);
        }
        [HttpGet(nameof(GetExutiveSummary))]
        public ExcutiveSummaryResponse GetExutiveSummary(long Id)
        {
            return _report.GetExcutiveSummary(Id);
        }
        [HttpGet(nameof(GetNegotiationExcutiveSummary))]
        public ExcutiveSummaryResponse GetNegotiationExcutiveSummary(long Id)
        {
            return _report.GetNegotiationExcutiveSummary(Id);
        }

        [HttpPost(nameof(GenerateExcutiveSummary))]
        public async Task<ActionResult<OperationStatusResponse>> GenerateExcutiveSummary([FromForm] ExcutiveSummaryRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var result = await _report.GenerateExcutiveSummary(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }

        [HttpPut(nameof(SendExcutiveSummaryApproval))]
        public async Task<ActionResult<OperationStatusResponse>> SendExcutiveSummaryApproval(ExcutiveSummaryApprovalRequest request)
        {
            var result = await _report.SendExcutiveSummaryApproval(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }
         [HttpPut(nameof(UpdateExcutiveSummary))]
        public async Task<ActionResult<OperationStatusResponse>> UpdateExcutiveSummary(ExcutiveSummaryRequest request)
        {
            var result = await _report.UpdateExcutiveSummary(request);
            if (result.Status == OperationStatus.SUCCESS)
                return Ok(result);
            else
                return StatusCode(500, result);
        }


        [HttpPost(nameof(CreateDetailEvaluationReport))]
        public async Task<ActionResult<OperationStatusResponse>> CreateDetailEvaluationReport([FromForm] DetailEvaluationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.EvaluationReport, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _report.CreateDetailEvaluationReport(request);

                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.EvaluationReport, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpPost(nameof(UpdateDetailEvaluationReport))]
        public async Task<IActionResult> UpdateDetailEvaluationReport([FromForm] DetailEvaluationUpdateRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var result = _report.UpdateDetailEvaluationReport(request).Result;
            if (result.Status == OperationStatus.SUCCESS)
                return StatusCode(200, result);
            else
                return StatusCode(500, result);
        }


        [HttpGet(nameof(GetDetailEvaluationReport))]
        public DetailEvaluaitionResponse GetDetailEvaluationReport(long Id)
        {
            return _report.GetDetailEvaluaionReport(Id);
        }

        [HttpGet(nameof(GetDetailEvaluaionReportDetail))]
        public DetailEvaluaitionResponse GetDetailEvaluaionReportDetail(long Id)
        {
            return _report.GetDetailEvaluaionReportDetail(Id);
        }
        [HttpPost(nameof(CreateNegotiationDetailEvaluationReport))]
        public async Task<ActionResult<OperationStatusResponse>> CreateNegotiationDetailEvaluationReport([FromForm] NegotiationDetailEvaluationRequest request)
        {
            var validation = _projectProcess.CheckProcess(ProjectTask.NegotiationReport, request.ProjectId);

            if (validation.PerformTask)
            {
                var result = await _report.CreateNegotiationDetailEvaluationReport(request);
                if (result.Status == OperationStatus.SUCCESS)
                {
                    _projectProcess.ChangeProcessStage(ProjectTask.NegotiationReport, request.ProjectId);
                    return Ok(result);
                }
                else
                    return StatusCode(500, result);
            }
            else
            {
                return StatusCode(401, new OperationStatusResponse { Status = OperationStatus.ERROR, Message = validation.Message });
            }
        }
        [HttpPut(nameof(UpdateNegotiationDetailEvaluationReport))]
        public async Task<ActionResult<OperationStatusResponse>> UpdateNegotiationDetailEvaluationReport([FromForm] DetailNegotiationEvaluationUpdateRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var result = _report.UpdateNegotiationDetailEvaluationReport(request).Result;
            if (result.Status == OperationStatus.SUCCESS)
                return StatusCode(200, result);
            else
                return StatusCode(500, result);
        }


        [HttpGet(nameof(GetNegotiationDetailEvaluaionReport))]
        public DetailEvaluaitionResponse GetNegotiationDetailEvaluaionReport(long Id)
        {
            return _report.GetNegotiationDetailEvaluaionReport(Id);
        }

        [HttpGet(nameof(GetNegotiationDetailEvaluaionReportDetail))]
        public DetailEvaluaitionResponse GetNegotiationDetailEvaluaionReportDetail(long Id)
        {
            return _report.GetNegotiationDetailEvaluaionReportDetail(Id);
        }

    }
}